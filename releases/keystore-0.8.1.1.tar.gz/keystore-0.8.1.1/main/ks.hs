import Data.KeyStore

main :: IO ()
main = cli
